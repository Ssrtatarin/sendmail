from django.shortcuts import render
from .models import M
from .forms import Mail
from .service import send
from django.views.generic import CreateView
from kek import forms

class ContactView(CreateView):
    model = M
    form_class = Mail
    success_url = '/'
    template_name = 'mail.html'


    def form_valid(self, form):
        form.save()
        send(form.instance.mail)
        return super().form_valid(form)
