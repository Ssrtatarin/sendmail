from django import forms
from .models import M


class Mail(forms.ModelForm):
    class Meta:
        model = M
        fields = '__all__'
