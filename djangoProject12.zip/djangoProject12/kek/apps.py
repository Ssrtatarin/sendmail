from django.apps import AppConfig


class KekConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kek'
