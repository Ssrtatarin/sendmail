from django.db import models

class M(models.Model):
    mail = models.EmailField(max_length=45)
